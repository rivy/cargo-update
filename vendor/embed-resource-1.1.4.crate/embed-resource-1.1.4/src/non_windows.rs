pub const SUPPORTED: bool = false;

pub fn compile_resource(_: &str, _: &str, _: &str) {}
