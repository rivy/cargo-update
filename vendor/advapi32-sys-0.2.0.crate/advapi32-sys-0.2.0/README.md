# advapi32 #
Contains function definitions for the Windows API library advapi32. See winapi for types and constants.

```toml
[dependencies]
advapi32-sys = "0.1.2"
```

```rust
extern crate advapi32;
```

[Documentation](https://retep998.github.io/doc/advapi32/)
