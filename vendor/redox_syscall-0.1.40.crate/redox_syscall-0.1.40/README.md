[Redox OS][1]'s syscall API

[Documentation][2]

[1]: https://github.com/redox-os/redox
[2]: https://docs.rs/redox_syscall

